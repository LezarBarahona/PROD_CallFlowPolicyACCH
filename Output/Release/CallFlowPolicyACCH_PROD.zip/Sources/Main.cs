using CallFlow.CFD;
using CallFlow;
using MimeKit;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks.Dataflow;
using System.Threading.Tasks;
using System.Threading;
using System;
using TCX.Configuration;

namespace CallFlowPolicyACCH_PROD
{
    public class Main : ScriptBase<Main>, ICallflow, ICallflowProcessor
    {
        private bool executionStarted;
        private bool executionFinished;
        private bool disconnectFlowPending;

        private BufferBlock<AbsEvent> eventBuffer;

        private int currentComponentIndex;
        private List<AbsComponent> mainFlowComponentList;
        private List<AbsComponent> disconnectFlowComponentList;
        private List<AbsComponent> errorFlowComponentList;
        private List<AbsComponent> currentFlowComponentList;

        private LogFormatter logFormatter;
        private TimerManager timerManager;
        private Dictionary<string, Variable> variableMap;
        private TempWavFileManager tempWavFileManager;
        private PromptQueue promptQueue;
        private OnlineServices onlineServices;

        private void DisconnectCallAndExitCallflow()
        {
            if (currentFlowComponentList == disconnectFlowComponentList)
                logFormatter.Trace("Callflow finished...");
            else
            {
                logFormatter.Trace("Callflow finished, disconnecting call...");
                MyCall.Terminate();
            }
        }

        private async Task ExecuteErrorFlow()
        {
            if (currentFlowComponentList == errorFlowComponentList)
            {
                logFormatter.Trace("Error during error handler flow, exiting callflow...");
                DisconnectCallAndExitCallflow();
            }
            else if (currentFlowComponentList == disconnectFlowComponentList)
            {
                logFormatter.Trace("Error during disconnect handler flow, exiting callflow...");
                executionFinished = true;
            }
            else
            {
                currentFlowComponentList = errorFlowComponentList;
                currentComponentIndex = 0;
                if (errorFlowComponentList.Count > 0)
                {
                    logFormatter.Trace("Start executing error handler flow...");
                    await ProcessStart();
                }
                else
                {
                    logFormatter.Trace("Error handler flow is empty...");
                    DisconnectCallAndExitCallflow();
                }
            }
        }

        private async Task ExecuteDisconnectFlow()
        {
            currentFlowComponentList = disconnectFlowComponentList;
            currentComponentIndex = 0;
            disconnectFlowPending = false;
            if (disconnectFlowComponentList.Count > 0)
            {
                logFormatter.Trace("Start executing disconnect handler flow...");
                await ProcessStart();
            }
            else
            {
                logFormatter.Trace("Disconnect handler flow is empty...");
                executionFinished = true;
            }
        }

        private EventResults CheckEventResult(EventResults eventResult)
        {
            if (eventResult == EventResults.MoveToNextComponent && ++currentComponentIndex == currentFlowComponentList.Count)
            {
                DisconnectCallAndExitCallflow();
                return EventResults.Exit;
            }
            else if (eventResult == EventResults.Exit)
                DisconnectCallAndExitCallflow();

            return eventResult;
        }

        private void InitializeVariables(string callID)
        {
            // Call variables
            variableMap["session.ani"] = new Variable(MyCall.Caller.CallerID);
            variableMap["session.callid"] = new Variable(callID);
            variableMap["session.dnis"] = new Variable(MyCall.DN.Number);
            variableMap["session.did"] = new Variable(MyCall.Caller.CalledNumber);
            variableMap["session.audioFolder"] = new Variable(Path.Combine(RecordingManager.Instance.AudioFolder, promptQueue.ProjectAudioFolder));
            variableMap["session.transferingExtension"] = new Variable(MyCall["onbehlfof"] ?? string.Empty);

            // Standard variables
            variableMap["RecordResult.NothingRecorded"] = new Variable(RecordComponent.RecordResults.NothingRecorded);
            variableMap["RecordResult.StopDigit"] = new Variable(RecordComponent.RecordResults.StopDigit);
            variableMap["RecordResult.Completed"] = new Variable(RecordComponent.RecordResults.Completed);
            variableMap["MenuResult.Timeout"] = new Variable(MenuComponent.MenuResults.Timeout);
            variableMap["MenuResult.InvalidOption"] = new Variable(MenuComponent.MenuResults.InvalidOption);
            variableMap["MenuResult.ValidOption"] = new Variable(MenuComponent.MenuResults.ValidOption);
            variableMap["UserInputResult.Timeout"] = new Variable(UserInputComponent.UserInputResults.Timeout);
            variableMap["UserInputResult.InvalidDigits"] = new Variable(UserInputComponent.UserInputResults.InvalidDigits);
            variableMap["UserInputResult.ValidDigits"] = new Variable(UserInputComponent.UserInputResults.ValidDigits);
            variableMap["VoiceInputResult.Timeout"] = new Variable(VoiceInputComponent.VoiceInputResults.Timeout);
            variableMap["VoiceInputResult.InvalidInput"] = new Variable(VoiceInputComponent.VoiceInputResults.InvalidInput);
            variableMap["VoiceInputResult.ValidInput"] = new Variable(VoiceInputComponent.VoiceInputResults.ValidInput);
            variableMap["VoiceInputResult.ValidDtmfInput"] = new Variable(VoiceInputComponent.VoiceInputResults.ValidDtmfInput);

            // User variables
            variableMap["callflow$.textAudio"] = new Variable("");
            variableMap["callflow$.textOptionExhibit"] = new Variable("");
            variableMap["callflow$.anexoEjecutivo"] = new Variable(8002);
            variableMap["callflow$.ContinueLoopingOption"] = new Variable(true);
            variableMap["RecordResult.NothingRecorded"] = new Variable(RecordComponent.RecordResults.NothingRecorded);
            variableMap["RecordResult.StopDigit"] = new Variable(RecordComponent.RecordResults.StopDigit);
            variableMap["RecordResult.Completed"] = new Variable(RecordComponent.RecordResults.Completed);
            variableMap["MenuResult.Timeout"] = new Variable(MenuComponent.MenuResults.Timeout);
            variableMap["MenuResult.InvalidOption"] = new Variable(MenuComponent.MenuResults.InvalidOption);
            variableMap["MenuResult.ValidOption"] = new Variable(MenuComponent.MenuResults.ValidOption);
            variableMap["UserInputResult.Timeout"] = new Variable(UserInputComponent.UserInputResults.Timeout);
            variableMap["UserInputResult.InvalidDigits"] = new Variable(UserInputComponent.UserInputResults.InvalidDigits);
            variableMap["UserInputResult.ValidDigits"] = new Variable(UserInputComponent.UserInputResults.ValidDigits);
            variableMap["VoiceInputResult.Timeout"] = new Variable(VoiceInputComponent.VoiceInputResults.Timeout);
            variableMap["VoiceInputResult.InvalidInput"] = new Variable(VoiceInputComponent.VoiceInputResults.InvalidInput);
            variableMap["VoiceInputResult.ValidInput"] = new Variable(VoiceInputComponent.VoiceInputResults.ValidInput);
            variableMap["VoiceInputResult.ValidDtmfInput"] = new Variable(VoiceInputComponent.VoiceInputResults.ValidDtmfInput);
            
        }

        private void InitializeComponents(ICallflow callflow, ICall myCall, string logHeader)
        {
            {
            UserInputComponent IngreseRut = new UserInputComponent("IngreseRut", callflow, myCall, logHeader);
            IngreseRut.AllowDtmfInput = true;
            IngreseRut.MaxRetryCount = 2;
            IngreseRut.FirstDigitTimeout = 6000;
            IngreseRut.InterDigitTimeout = 8000;
            IngreseRut.FinalDigitTimeout = 3000;
            IngreseRut.MinDigits = 1;
            IngreseRut.MaxDigits = 10;
            IngreseRut.ValidDigitList.AddRange(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '*' });
            IngreseRut.InitialPrompts.Add(new AudioFilePrompt(() => { return "1_ingreseRut.wav"; }));
            IngreseRut.SubsequentPrompts.Add(new AudioFilePrompt(() => { return "transferirEjecutivo.wav"; }));
            IngreseRut.InvalidDigitPrompts.Add(new AudioFilePrompt(() => { return "transferirEjecutivo.wav"; }));
            mainFlowComponentList.Add(IngreseRut);
            ConditionalComponent IngreseRut_Conditional = new ConditionalComponent("IngreseRut_Conditional", callflow, myCall, logHeader);
            mainFlowComponentList.Add(IngreseRut_Conditional);
            IngreseRut_Conditional.ConditionList.Add(() => { return IngreseRut.Result == UserInputComponent.UserInputResults.ValidDigits; });
            IngreseRut_Conditional.ContainerList.Add(new SequenceContainerComponent("IngreseRut_Conditional_ValidInput", callflow, myCall, logHeader));
            LoopComponent Loop1 = new LoopComponent("Loop1", callflow, myCall, logHeader);
            Loop1.Condition = () => { return Convert.ToBoolean(variableMap["callflow$.ContinueLoopingOption"].Value); };
            Loop1.Container = new SequenceContainerComponent("Loop1_Container", callflow, myCall, logHeader);
            IngreseRut_Conditional.ContainerList[0].ComponentList.Add(Loop1);
            VariableAssignmentComponent ContinueLoopingOptionFalse = new VariableAssignmentComponent("ContinueLoopingOptionFalse", callflow, myCall, logHeader);
            ContinueLoopingOptionFalse.VariableName = "callflow$.ContinueLoopingOption";
            ContinueLoopingOptionFalse.VariableValueHandler = () => { return false; };
            Loop1.Container.ComponentList.Add(ContinueLoopingOptionFalse);
            ConditionalComponent ConditionInputRut = new ConditionalComponent("ConditionInputRut", callflow, myCall, logHeader);
            Loop1.Container.ComponentList.Add(ConditionInputRut);
            ConditionInputRut.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.NOT_EQUAL(IngreseRut.Buffer,"0")); });
            ConditionInputRut.ContainerList.Add(new SequenceContainerComponent("input_notequal_zero", callflow, myCall, logHeader));
            WebInteractionComponent ivrapi = new WebInteractionComponent("ivrapi", callflow, myCall, logHeader);
            ivrapi.HttpMethod = System.Net.Http.HttpMethod.Get;
            ivrapi.ContentType = "application/x-www-form-urlencoded";
            ivrapi.Timeout = 30000;
            ivrapi.UriHandler = () => { return Convert.ToString(CFDFunctions.CONCATENATE(Convert.ToString("https://macc-ivrapi-apimng-prod.azure-api.net/macc-ivrapi-function-prod/InsurancePolicyAudioByRut/"),Convert.ToString(IngreseRut.Buffer))); };
            ivrapi.ContentHandler = () => { return Convert.ToString(""); };
            ivrapi.Headers.Add(new CallFlow.CFD.Parameter("Ocp-Apim-Subscription-Key", () => { return "337c862072c04edb9b3f0a3feb252569"; }));
            ConditionInputRut.ContainerList[0].ComponentList.Add(ivrapi);
            TextAnalyzerComponent JsonXmlParser1 = new TextAnalyzerComponent("JsonXmlParser1", callflow, myCall, logHeader);
            JsonXmlParser1.TextType = TextAnalyzerComponent.TextTypes.JSON;
            JsonXmlParser1.TextHandler = () => { return Convert.ToString(ivrapi.ResponseContent); };
            JsonXmlParser1.Mappings.Add("textAudio", "callflow$.textAudio");
            JsonXmlParser1.Mappings.Add("textOptionExhibit", "callflow$.textOptionExhibit");
            ConditionInputRut.ContainerList[0].ComponentList.Add(JsonXmlParser1);
            UserInputComponent IngreseOpcion = new UserInputComponent("IngreseOpcion", callflow, myCall, logHeader);
            IngreseOpcion.AllowDtmfInput = true;
            IngreseOpcion.MaxRetryCount = 2;
            IngreseOpcion.FirstDigitTimeout = 5000;
            IngreseOpcion.InterDigitTimeout = 3000;
            IngreseOpcion.FinalDigitTimeout = 2000;
            IngreseOpcion.MinDigits = 1;
            IngreseOpcion.MaxDigits = 1;
            IngreseOpcion.ValidDigitList.AddRange(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });
            IngreseOpcion.InitialPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Lucia", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString(variableMap["callflow$.textAudio"].Value); }));
            IngreseOpcion.SubsequentPrompts.Add(new AudioFilePrompt(() => { return "transferirEjecutivo.wav"; }));
            IngreseOpcion.InvalidDigitPrompts.Add(new TextToSpeechAudioPrompt(myCall, logHeader, onlineServices.TextToSpeechEngine, "Lupe", TextToSpeechAudioPrompt.TextToSpeechVoiceTypes.Standard, TextToSpeechAudioPrompt.TextToSpeechFormats.Text, () => { return Convert.ToString("opcion invalida"); }));
            ConditionInputRut.ContainerList[0].ComponentList.Add(IngreseOpcion);
            ConditionalComponent IngreseOpcion_Conditional = new ConditionalComponent("IngreseOpcion_Conditional", callflow, myCall, logHeader);
            ConditionInputRut.ContainerList[0].ComponentList.Add(IngreseOpcion_Conditional);
            IngreseOpcion_Conditional.ConditionList.Add(() => { return IngreseOpcion.Result == UserInputComponent.UserInputResults.ValidDigits; });
            IngreseOpcion_Conditional.ContainerList.Add(new SequenceContainerComponent("IngreseOpcion_Conditional_ValidInput", callflow, myCall, logHeader));
            ExecuteCSharpCodeAnexo524797157ECCComponent ExecuteCSharpCodeAnexo = new ExecuteCSharpCodeAnexo524797157ECCComponent("ExecuteCSharpCodeAnexo", callflow, myCall, logHeader);
            ExecuteCSharpCodeAnexo.Parameters.Add(new CallFlow.CFD.Parameter("jsonInput", () => { return ivrapi.ResponseContent; }));
            ExecuteCSharpCodeAnexo.Parameters.Add(new CallFlow.CFD.Parameter("optionUser", () => { return IngreseOpcion.Buffer; }));
            ExecuteCSharpCodeAnexo.Parameters.Add(new CallFlow.CFD.Parameter("textOptionExhibit", () => { return variableMap["callflow$.textOptionExhibit"].Value; }));
            IngreseOpcion_Conditional.ContainerList[0].ComponentList.Add(ExecuteCSharpCodeAnexo);
            ConditionalComponent ConditionInputOption = new ConditionalComponent("ConditionInputOption", callflow, myCall, logHeader);
            IngreseOpcion_Conditional.ContainerList[0].ComponentList.Add(ConditionInputOption);
            ConditionInputOption.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.EQUAL(IngreseOpcion.Buffer,"0")); });
            ConditionInputOption.ContainerList.Add(new SequenceContainerComponent("inputOpcion_equal_zero", callflow, myCall, logHeader));
            PromptPlaybackComponent PromptEjecutivo = new PromptPlaybackComponent("PromptEjecutivo", callflow, myCall, logHeader);
            PromptEjecutivo.AllowDtmfInput = true;
            PromptEjecutivo.Prompts.Add(new AudioFilePrompt(() => { return "transferirEjecutivo.wav"; }));
            ConditionInputOption.ContainerList[0].ComponentList.Add(PromptEjecutivo);
            TransferComponent TransferEjecutivo = new TransferComponent("TransferEjecutivo", callflow, myCall, logHeader);
            TransferEjecutivo.DestinationHandler = () => { return Convert.ToString(variableMap["callflow$.anexoEjecutivo"].Value); };
            TransferEjecutivo.DelayMilliseconds = 500;
            ConditionInputOption.ContainerList[0].ComponentList.Add(TransferEjecutivo);
            ConditionInputOption.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.NOT_EQUAL(ExecuteCSharpCodeAnexo.ReturnValue,"SO")); });
            ConditionInputOption.ContainerList.Add(new SequenceContainerComponent("inputOpcion_notequal_zero", callflow, myCall, logHeader));
            PromptPlaybackComponent PromptConvenio = new PromptPlaybackComponent("PromptConvenio", callflow, myCall, logHeader);
            PromptConvenio.AllowDtmfInput = true;
            PromptConvenio.Prompts.Add(new AudioFilePrompt(() => { return "transferirConvenio.wav"; }));
            ConditionInputOption.ContainerList[1].ComponentList.Add(PromptConvenio);
            TransferComponent TransferConvenio = new TransferComponent("TransferConvenio", callflow, myCall, logHeader);
            TransferConvenio.DestinationHandler = () => { return Convert.ToString(ExecuteCSharpCodeAnexo.ReturnValue); };
            TransferConvenio.DelayMilliseconds = 500;
            ConditionInputOption.ContainerList[1].ComponentList.Add(TransferConvenio);
            ConditionInputOption.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.EQUAL(IngreseOpcion.Buffer,"9")); });
            ConditionInputOption.ContainerList.Add(new SequenceContainerComponent("conditionalComponentBranch1", callflow, myCall, logHeader));
            VariableAssignmentComponent AssignVariable2 = new VariableAssignmentComponent("AssignVariable2", callflow, myCall, logHeader);
            AssignVariable2.VariableName = "callflow$.ContinueLoopingOption";
            AssignVariable2.VariableValueHandler = () => { return true; };
            ConditionInputOption.ContainerList[2].ComponentList.Add(AssignVariable2);
            IngreseOpcion_Conditional.ConditionList.Add(() => { return IngreseOpcion.Result == UserInputComponent.UserInputResults.InvalidDigits || IngreseOpcion.Result == UserInputComponent.UserInputResults.Timeout; });
            IngreseOpcion_Conditional.ContainerList.Add(new SequenceContainerComponent("IngreseOpcion_Conditional_InvalidInput", callflow, myCall, logHeader));
            PromptPlaybackComponent PromptEjecutivo2 = new PromptPlaybackComponent("PromptEjecutivo2", callflow, myCall, logHeader);
            PromptEjecutivo2.AllowDtmfInput = true;
            PromptEjecutivo2.Prompts.Add(new AudioFilePrompt(() => { return "transferirEjecutivo.wav"; }));
            IngreseOpcion_Conditional.ContainerList[1].ComponentList.Add(PromptEjecutivo2);
            TransferComponent TransferEjecutivo2 = new TransferComponent("TransferEjecutivo2", callflow, myCall, logHeader);
            TransferEjecutivo2.DestinationHandler = () => { return Convert.ToString(variableMap["callflow$.anexoEjecutivo"].Value); };
            TransferEjecutivo2.DelayMilliseconds = 500;
            IngreseOpcion_Conditional.ContainerList[1].ComponentList.Add(TransferEjecutivo2);
            ConditionInputRut.ConditionList.Add(() => { return Convert.ToBoolean(CFDFunctions.EQUAL(IngreseRut.Buffer,"0")); });
            ConditionInputRut.ContainerList.Add(new SequenceContainerComponent("input_equal_zero", callflow, myCall, logHeader));
            PromptPlaybackComponent PromptEjecutivo4 = new PromptPlaybackComponent("PromptEjecutivo4", callflow, myCall, logHeader);
            PromptEjecutivo4.AllowDtmfInput = true;
            PromptEjecutivo4.Prompts.Add(new AudioFilePrompt(() => { return "transferirEjecutivo.wav"; }));
            ConditionInputRut.ContainerList[1].ComponentList.Add(PromptEjecutivo4);
            TransferComponent TransferEjecutivo4 = new TransferComponent("TransferEjecutivo4", callflow, myCall, logHeader);
            TransferEjecutivo4.DestinationHandler = () => { return Convert.ToString(variableMap["callflow$.anexoEjecutivo"].Value); };
            TransferEjecutivo4.DelayMilliseconds = 500;
            ConditionInputRut.ContainerList[1].ComponentList.Add(TransferEjecutivo4);
            IngreseRut_Conditional.ConditionList.Add(() => { return IngreseRut.Result == UserInputComponent.UserInputResults.InvalidDigits || IngreseRut.Result == UserInputComponent.UserInputResults.Timeout; });
            IngreseRut_Conditional.ContainerList.Add(new SequenceContainerComponent("IngreseRut_Conditional_InvalidInput", callflow, myCall, logHeader));
            PromptPlaybackComponent PromptEjecutivo3 = new PromptPlaybackComponent("PromptEjecutivo3", callflow, myCall, logHeader);
            PromptEjecutivo3.AllowDtmfInput = true;
            PromptEjecutivo3.Prompts.Add(new AudioFilePrompt(() => { return "transferirEjecutivo.wav"; }));
            IngreseRut_Conditional.ContainerList[1].ComponentList.Add(PromptEjecutivo3);
            TransferComponent TransferEjecutivo3 = new TransferComponent("TransferEjecutivo3", callflow, myCall, logHeader);
            TransferEjecutivo3.DestinationHandler = () => { return Convert.ToString(variableMap["callflow$.anexoEjecutivo"].Value); };
            TransferEjecutivo3.DelayMilliseconds = 500;
            IngreseRut_Conditional.ContainerList[1].ComponentList.Add(TransferEjecutivo3);
            }
            {
            }
            {
            }
            

            // Add a final DisconnectCall component to the main and error handler flows, in order to complete pending prompt playbacks...
            DisconnectCallComponent mainAutoAddedFinalDisconnectCall = new DisconnectCallComponent("mainAutoAddedFinalDisconnectCall", callflow, myCall, logHeader);
            DisconnectCallComponent errorHandlerAutoAddedFinalDisconnectCall = new DisconnectCallComponent("errorHandlerAutoAddedFinalDisconnectCall", callflow, myCall, logHeader);
            mainFlowComponentList.Add(mainAutoAddedFinalDisconnectCall);
            errorFlowComponentList.Add(errorHandlerAutoAddedFinalDisconnectCall);
        }

        private bool IsServerInHoliday(ICall myCall)
        {
            Tenant tenant = myCall.PS.GetTenant();
            return tenant != null && tenant.IsHoliday(new DateTimeOffset(DateTime.Now));
        }

        private bool IsServerOfficeHourActive(ICall myCall)
        {
            Tenant tenant = myCall.PS.GetTenant();
            if (tenant == null) return false;

            string overrideOfficeTime = tenant.GetPropertyValue("OVERRIDEOFFICETIME");
            if (!String.IsNullOrEmpty(overrideOfficeTime))
            {
                if (overrideOfficeTime == "1") // Forced to in office hours
                    return true;
                else if (overrideOfficeTime == "2") // Forced to out of office hours
                    return false;
            }

            DateTime nowDt = DateTime.Now;
            if (tenant.IsHoliday(new DateTimeOffset(nowDt))) return false;

            Schedule officeHours = tenant.Hours;
            Nullable<bool> result = officeHours.IsActiveTime(nowDt);
            return result.GetValueOrDefault(false);
        }

        public Main()
        {
            this.executionStarted = false;
            this.executionFinished = false;
            this.disconnectFlowPending = false;

            this.eventBuffer = new BufferBlock<AbsEvent>();

            this.currentComponentIndex = 0;
            this.mainFlowComponentList = new List<AbsComponent>();
            this.disconnectFlowComponentList = new List<AbsComponent>();
            this.errorFlowComponentList = new List<AbsComponent>();
            this.currentFlowComponentList = mainFlowComponentList;

            this.timerManager = new TimerManager();
            this.timerManager.OnTimeout += (state) => eventBuffer.Post(new TimeoutEvent(state));
            this.variableMap = new Dictionary<string, Variable>();

            AbsTextToSpeechEngine textToSpeechEngine = new AmazonPollyTextToSpeechEngine(new AmazonPollySettings("AKIAQCGYYWTE6FE3ZDI6", "TC6Gwxr+YQB2JfJXhBgD9mfycA8kQpACYOVjalJd", "sa-east-1", new List<string>() {  }));
            AbsSpeechToTextEngine speechToTextEngine = null;
            this.onlineServices = new OnlineServices(textToSpeechEngine, speechToTextEngine);
        }

        public override void Start()
        {
            MyCall.SetBackgroundAudio(false, new string[] { });

            string callID = MyCall?.Caller["chid"] ?? "Unknown";
            string logHeader = $"CallFlowPolicyACCH_PROD - CallID {callID}";
            this.logFormatter = new LogFormatter(MyCall, logHeader, "Callflow");
            this.promptQueue = new PromptQueue(this, MyCall, "CallFlowPolicyACCH_PROD", logHeader);
            this.tempWavFileManager = new TempWavFileManager(logFormatter);
            this.timerManager.CallStarted();

            InitializeComponents(this, MyCall, logHeader);
            InitializeVariables(callID);
            
            MyCall.OnTerminated += () => eventBuffer.Post(new CallTerminatedEvent());
            MyCall.OnDTMFInput += x => eventBuffer.Post(new DTMFReceivedEvent(x));

            logFormatter.Trace("Start executing main flow...");
            eventBuffer.Post(new StartEvent());
            Task.Run(() => EventProcessingLoop());

            
        }

        public void PostStartEvent()
        {
            eventBuffer.Post(new StartEvent());
        }

        public void PostDTMFReceivedEvent(char digit)
        {
            eventBuffer.Post(new DTMFReceivedEvent(digit));
        }

        public void PostPromptPlayedEvent()
        {
            eventBuffer.Post(new PromptPlayedEvent());
        }

        public void PostTransferFailedEvent()
        {
            eventBuffer.Post(new TransferFailedEvent());
        }

        public void PostMakeCallResultEvent(bool result)
        {
            eventBuffer.Post(new MakeCallResultEvent(result));
        }

        public void PostCallTerminatedEvent()
        {
            eventBuffer.Post(new CallTerminatedEvent());
        }

        public void PostTimeoutEvent(object state)
        {
            eventBuffer.Post(new TimeoutEvent(state));
        }

        private async Task EventProcessingLoop()
        {
            executionStarted = true;
            while (!executionFinished)
            {
                AbsEvent evt = await eventBuffer.ReceiveAsync();
                await evt?.ProcessEvent(this);
            }
        }
        
        public async Task ProcessStart()
        {
            try
            {
                EventResults eventResult;
                do
                {
                    AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                    logFormatter.Trace("Start executing component '" + currentComponent.Name + "'");
                    eventResult = await currentComponent.Start(timerManager, variableMap, tempWavFileManager, promptQueue);
                }
                while (CheckEventResult(eventResult) == EventResults.MoveToNextComponent);

                if (eventResult == EventResults.Exit) executionFinished = true;
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessDTMFReceived(char digit)
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnDTMFReceived for component '" + currentComponent.Name + "' - Digit: '" + digit + "'");
                EventResults eventResult = CheckEventResult(await currentComponent.OnDTMFReceived(timerManager, variableMap, tempWavFileManager, promptQueue, digit));
                if (eventResult == EventResults.MoveToNextComponent)
                { 
                    if (disconnectFlowPending)
                        await ExecuteDisconnectFlow();
                    else
                        await ProcessStart();
                }
                else if (eventResult == EventResults.Exit)
                    executionFinished = true;
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessPromptPlayed()
        {
            try
            {
                promptQueue.NotifyPlayFinished();
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnPromptPlayed for component '" + currentComponent.Name + "'");
                EventResults eventResult = CheckEventResult(await currentComponent.OnPromptPlayed(timerManager, variableMap, tempWavFileManager, promptQueue));
                if (eventResult == EventResults.MoveToNextComponent)
                { 
                    if (disconnectFlowPending)
                        await ExecuteDisconnectFlow();
                    else
                        await ProcessStart();
                }
                else if (eventResult == EventResults.Exit)
                    executionFinished = true;
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessTransferFailed()
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnTransferFailed for component '" + currentComponent.Name + "'");
                EventResults eventResult = CheckEventResult(await currentComponent.OnTransferFailed(timerManager, variableMap, tempWavFileManager, promptQueue));
                if (eventResult == EventResults.MoveToNextComponent)
                { 
                    if (disconnectFlowPending)
                        await ExecuteDisconnectFlow();
                    else
                        await ProcessStart();
                }
                else if (eventResult == EventResults.Exit)
                    executionFinished = true;
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessMakeCallResult(bool result)
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnMakeCallResult for component '" + currentComponent.Name + "' - Result: '" + result + "'");
                EventResults eventResult = CheckEventResult(await currentComponent.OnMakeCallResult(timerManager, variableMap, tempWavFileManager, promptQueue, result));
                if (eventResult == EventResults.MoveToNextComponent)
                { 
                    if (disconnectFlowPending)
                        await ExecuteDisconnectFlow();
                    else
                        await ProcessStart();
                }
                else if (eventResult == EventResults.Exit)
                    executionFinished = true;
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }

        public async Task ProcessCallTerminated()
        {
            try
            {
                if (executionStarted)
                {
                    // First notify the call termination to the current component
                    AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                    logFormatter.Trace("OnCallTerminated for component '" + currentComponent.Name + "'");

                    // Don't wrap around CheckEventResult, because the call has been already disconnected, 
                    // and the following action to execute depends on the returned value.
                    EventResults eventResult = await currentComponent.OnCallTerminated(timerManager, variableMap, tempWavFileManager, promptQueue);
                    if (eventResult == EventResults.MoveToNextComponent)
                    {
                        // Next, if the current component has completed its job, execute the disconnect flow
                        await ExecuteDisconnectFlow();
                    }
                    else if (eventResult == EventResults.Wait)
                    {
                        // If the user component needs more events, wait for it to finish, and signal here that we need to execute
                        // the disconnect handler flow of the callflow next...
                        disconnectFlowPending = true;
                    }
                    else if (eventResult == EventResults.Exit)
                        executionFinished = true;
                }
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
            finally
            {
                // Finally, delete temporary files
                tempWavFileManager.DeleteFilesAndFolders();
            }
        }

        public async Task ProcessTimeout(object state)
        {
            try
            {
                AbsComponent currentComponent = currentFlowComponentList[currentComponentIndex];
                logFormatter.Trace("OnTimeout for component '" + currentComponent.Name + "'");
                EventResults eventResult = CheckEventResult(await currentComponent.OnTimeout(timerManager, variableMap, tempWavFileManager, promptQueue, state));
                if (eventResult == EventResults.MoveToNextComponent)
                { 
                    if (disconnectFlowPending)
                        await ExecuteDisconnectFlow();
                    else
                        await ProcessStart();
                }
                else if (eventResult == EventResults.Exit)
                    executionFinished = true;
            }
            catch (Exception exc)
            {
                logFormatter.Error("Error executing last component: " + exc.ToString());
                await ExecuteErrorFlow();
            }
        }


        public class ExecuteCSharpCodeAnexo524797157ECCComponent : ExternalCodeExecutionComponent
            {
                public List<CallFlow.CFD.Parameter> Parameters { get; } = new List<CallFlow.CFD.Parameter>();
                public ExecuteCSharpCodeAnexo524797157ECCComponent(string name, ICallflow callflow, ICall myCall, string projectName) : base(name, callflow, myCall, projectName) {}
                protected override object ExecuteCode()
                {
                    return anexo(Convert.ToString(Parameters[0].Value), Convert.ToString(Parameters[1].Value), Convert.ToString(Parameters[2].Value));
                }
            
            private object anexo(string jsonInput, string optionUser, string textOptionExhibit)
                {
                    string[] options = textOptionExhibit.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

        // Crear un arreglo de opciones
        string[] optionArray = new string[options.Length];
       
        // Recorrer las opciones y eliminar espacios en blanco
        for (int i = 0; i < options.Length; i++)
        {
            if( options[i].Trim().Split(':')[0]== optionUser)
           {
               return options[i].Trim().Split(':')[1];
           }
        }
return "SO";    }
            }
            
    }
}
